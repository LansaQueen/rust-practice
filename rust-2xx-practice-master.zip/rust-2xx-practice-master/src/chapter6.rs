/// https://practice.course.rs/compound-types/string.html
#[test]
fn test61() {

}