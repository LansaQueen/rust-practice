/// https://practice.course.rs/basic-types/numbers.html
#[test]
fn test41() {

}