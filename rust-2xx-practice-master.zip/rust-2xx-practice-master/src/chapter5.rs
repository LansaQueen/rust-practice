/// https://practice.course.rs/ownership/ownership.html
#[test]
fn test51() {

}